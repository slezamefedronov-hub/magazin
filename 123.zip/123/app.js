// Год в футере
const y = document.getElementById('y');
if (y) y.textContent = new Date().getFullYear();

// Подсветка активной вкладки в шапке
(() => {
  const path = location.pathname.replace(/\\/g, '/');
  document.querySelectorAll('.site-header .nav .chip').forEach(a => {
    const key = a.dataset.nav;
    if (key === 'shop' && path.includes('/shop/')) a.classList.add('active');
    else if (key === 'home' && !path.includes('/shop/')) a.classList.add('active');
  });
})();

// ===== Reveal-анимация карточек на главной =====
(() => {
  const grid = document.querySelector('.home-grid');
  if (!grid) return; // мы не на главной

  const cards = Array.from(grid.querySelectorAll('.card'));
  // начальное состояние и задержка "ступенькой"
  cards.forEach((el, i) => {
    el.classList.add('reveal-init');
    el.style.setProperty('--reveal-delay', `${i * 80}ms`); // 0ms, 80ms, 160ms, ...
  });

  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add('reveal-in');
        e.target.classList.remove('reveal-init');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.15 });

  cards.forEach(el => io.observe(el));
})();
