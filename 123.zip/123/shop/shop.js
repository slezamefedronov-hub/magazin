// Год
const yy = document.getElementById('y');
if (yy) yy.textContent = new Date().getFullYear();

// Подсветка активной вкладки
(() => {
  const path = location.pathname.replace(/\\/g,'/');
  document.querySelectorAll('.site-header .nav .chip').forEach(a => {
    const key = a.dataset.nav;
    if (key === 'shop' && path.includes('/shop/')) a.classList.add('active');
    else if (key === 'home' && !path.includes('/shop/')) a.classList.add('active');
  });
})();

/* Селекты/табы/сортировка */
document.querySelectorAll('.select').forEach(sel=>{
  const btn = sel.querySelector('.select-btn');
  btn.addEventListener('click',()=>sel.classList.toggle('open'));
  sel.querySelectorAll('li').forEach(li=>{
    li.addEventListener('click',()=>{
      sel.querySelectorAll('li').forEach(n=>n.classList.remove('active'));
      li.classList.add('active');
      btn.querySelector('span').textContent = li.textContent;
      sel.classList.remove('open');
      applyFilters();
    });
  });
});
document.addEventListener('click',e=>{
  document.querySelectorAll('.select').forEach(s=>{ if(!s.contains(e.target)) s.classList.remove('open'); });
});
const tabs = document.getElementById('tabs');
if (tabs) tabs.addEventListener('click',e=>{
  const t = e.target.closest('.tab'); if(!t) return;
  tabs.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
  t.classList.add('active'); applyFilters();
});

function applyFilters(){
  const activeCat = document.querySelector('.tab.active')?.dataset.cat || 'all';
  const pricePref = document.querySelector('[data-select="price"] .active')?.dataset.value || 'any';
  const sortPref  = document.querySelector('[data-select="sort"] .active')?.dataset.value || 'popular';

  const cards = [...document.querySelectorAll('.card')];
  cards.forEach(c=> c.style.display = (activeCat==='all'||c.dataset.cat===activeCat)?'':'none');
  const visible = cards.filter(c=>c.style.display!=='none');
  const grid = document.getElementById('grid');
  const num = (el,k)=>parseFloat(el.dataset[k]||'0');

  visible.sort((a,b)=>{
    if(pricePref==='asc') return num(a,'price')-num(b,'price');
    if(pricePref==='desc') return num(b,'price')-num(a,'price');
    if(sortPref==='rating') return num(b,'rating')-num(a,'rating');
    if(sortPref==='popular') return num(b,'reviews')-num(a,'reviews');
    return 0;
  });
  visible.forEach(c=>grid.appendChild(c));
}
applyFilters();
